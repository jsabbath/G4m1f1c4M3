A Pen created at CodePen.io. You can find this one at http://codepen.io/tinvalerio/pen/eqvDr.

 Hearts, flowers, medals or trophies.

Sure you can do a lot simply by using unicode symbols, but sometimes you want more.  SVGs allow infinitely customizable multi-coloured images.  Tucking those SVGs into your CSS as a data URI allows for clean, semantic mark-up.  

There are limitations of data URIs, however.  For starters, you need to encode your SVG; I've written up [tips for url-encoding your image](http://codepen.io/AmeliaBR/details/xijuv#comment-id-41169), but even that doesn't work in IE (unless you want to encode every quotation mark), so live sites will need base64-encoding. 

In addition, the data URI SVG is inaccessible to CSS manipulation from the parent document, so you can't change the image without over-writing it completely (as in the medals example).  But you can still change the look of the image by changing other background properties, as I demonstrate with hover effects.  