<?php 
	//crear cuenta
 ?>
<?php include('include/header.php'); ?>

	<div class="cuerpo">
		<h1>Crear una cuenta</h1>
		<div>
			<p class="indicaciones">
				Me gusta la plataforma y deseo ser parte de esta.
				Pues bien, si esa es tu afirmación entonces que esperas para formar parte de esta comunidad?
				Rellena todos los campos correspondientes a este formulario y pulsa sobre el boton registrar.
			</p>
		</div>

		<!--login form-->
		<div class="form">
			<form action="perfil.php">
				<!--div class="input">
					<img class="imgavatar" src="img/askalex.jpg" alt="">
				</div-->
				<div class="input">
					<input type="text" maxlength="20" placeholder="Usuario"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="text" placeholder="Nombres"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="text" placeholder="Apellidos"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="email" placeholder="Correo"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="password" placeholder="Contraseña"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="password" placeholder="Repita contraseña"  autocomplete="on" required>
				</div>
				<div class="input">
					<input class="button naranja" type="reset" value="Limpiar">
				</div>
				<div class="input">
					<input class="button celeste" type="submit" value="Crear">
				</div>
				<div class="input">
					<a href="terminosycondiciones.php">Terminos y condiciones</a>
				</div>
				<div class="input">
					<a href="index.php">Sácame de aquí</a>
				</div>
			</form>
			
		</div>
		<div class="fila">
			<ul>
				<a href="https://twitter.com" ><li></li></a>
				<a href="https://www.twitter.com"><li></li></a>
				<a href="https://www.googleplus.com"><li></li></a>
				<a href="https://www.linkedin.com"><li></li></a>
			</ul>
		</div>
		
	</div>
<?php include('include/footer.php'); ?>
