<?php include('include/header.php'); ?>

<div class="cuerpo">
	<div>
		<div class="paralax">
			
		</div>
	</div>
	<div class="">
		<p>
			<img src="img/male.png" class="imgperfil" alt="">
		</p>

		<div class="nombres">
			<h1 class="">El profe guille</h1>
			<h2>(Docente)</h2>
			<div class="fila">
				<ul>
					<a href=""><li></li></a>
					<a href=""><li></li></a>
					<a href=""><li></li></a>
					<a href=""><li></li></a>
				</ul>
			</div>
		</div>
		
		<p class="nombres">
			<blockquote>
				<p class="pcita">
					“Cuando tenía 16 años sólo tenía dos cosas en la cabeza, chicas y coches. No era muy bueno con las chicas, así que pensaba en coches. También pensaba en chicas, pero tenía más suerte con los coches”.
					<p class="pautor">-Warren Buffett-</p>
				</p>				
			</blockquote>
		</p>
		</aside>
		<div class="section">
			<section>
				<h2>Mi información</h2>
				<p>Deporte: balonpie</p>
				<p>Comida: Arroz verde</p>
				<p>Seccion: 6to B</p>
			</section>
		</div>

		<div class="section">
			<section>
				<div class="imgprlx">
					<img src="img/banner7.jpg" alt="" width="100%">
				</div>
				<p class="cp">
					<p class="cptitulo">Titulo</p>
					<p class="cpcuerpo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum, itaque, cupiditate dolorem asperiores ipsa ullam distinctio hic harum voluptas ut, quo veritatis beatae sed ex at possimus. Doloribus, omnis corporis?</p></p>
					<p>
						<div class="fila">
					<ul>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
					</ul>
			</div>
				</p>
			</section>
		</div>

		<div class="section">
			<section>
				<div class="imgprlx">
					<img src="img/FB_IMG_1458122116166.jpg" alt="" width="100%">
				</div>
				<p class="cp">
					<p class="cptitulo">Titulo</p>
					<p class="cpcuerpo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum, itaque, cupiditate dolorem asperiores ipsa ullam distinctio hic harum voluptas ut, quo veritatis beatae sed ex at possimus. Doloribus, omnis corporis?</p></p>
					<p>
						<div class="fila">
					<ul>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
						<a href=""><li></li></a>
					</ul>
			</div>
				</p>
			</section>
		</div>
		<div class="section">
			<section>
				<div class="imgprlx">
					<img src="img/FB_IMG_1458122097918.jpg" alt="" width="100%">
				</div>
				<p class="cp">
					<p class="cptitulo">Titulo</p>
					<p class="cpcuerpo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum, itaque, cupiditate dolorem asperiores ipsa ullam distinctio hic harum voluptas ut, quo veritatis beatae sed ex at possimus. Doloribus, omnis corporis?</p></p>
					<p>
					<div class="fila">
							<ul>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
							</ul>
					</div>
				</p>
			</section>
		</div>


		<div class="section">
			<section>
				<div class="imgprlx">
					<img src="img/FB_IMG_1458122097918.jpg" alt="" width="100%">
				</div>
				<p class="cp">
					<p class="cpt font-itulo">Titulo</p>
					<p class="cpcuerpo">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illum, itaque, cupiditate dolorem asperiores ipsa ullam distinctio hic harum voluptas ut, quo veritatis beatae sed ex at possimus. Doloribus, omnis corporis?</p></p>
					<p>
					<div class="fila">
							<ul>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
								<a href=""><li></li></a>
							</ul>
					</div>
				</p>
			</section>
		</div>

		<!--Quiero saber mas-->
		<section>
			<p><input type="button" class="button naranja" value="Ver entradas antiguas"></p>
			
		</section>
		

		<!--login form-->
		<!--div class="form">
			<div class="input">
				<img class="imgavatar" src="img/askalex.jpg" alt="">
			</div>
			<div class="input">
				<input type="text" maxlength="20" placeholder="Usuario">
			</div>
			<div class="input">
				<input type="password" placeholder="Contraseña">
			</div>
			<div class="input">
				<input class="button naranja" type="submit" value="Ingresar">
			</div>
		</div-->	
</div>

<?php include('include/footer.php'); ?>