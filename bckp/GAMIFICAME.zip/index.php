<?php include('include/header.php'); ?>

	<div class="cuerpo">
		<h1>Login</h1>
		<div>
			<p class="indicaciones">
				Bienvenido a la plataforma Sarmiento, para acceder al sistema ingresa tu cuenta, de caso no poseerla, debes de registrarte o ingresar como invitado si asi lo deseas.
			</p>
		</div>

		<!--login form-->
		<div class="form">
			<form action="perfil.php">
				<div class="input">
					<img class="imgavatar" src="img/ank.jpg" alt="">
				</div>
				<div class="input">
					<input type="text" maxlength="20" placeholder="Usuario"  autocomplete="on" required="">
				</div>
				<div class="input">
					<input type="password" placeholder="Contraseña"  autocomplete="on" required>
				</div>
				<div class="input">
					<input class="button naranja" type="submit" value="Ingresar">
				</div>
				<div class="input">
					<a href="crearcuenta.php">Crear cuenta</a>
				</div>
				<div class="input">
					<a href="recuperarcuenta.php">Olvide mi contraseña</a>
				</div>
			</form>
			
		</div>
		<div class="fila">
			<ul>
				<a href="https://twitter.com" ><li></li></a>
				<a href="https://www.twitter.com"><li></li></a>
				<a href="https://www.googleplus.com"><li></li></a>
				<a href="https://www.linkedin.com"><li></li></a>
			</ul>
		</div>
		
	</div>
<?php include('include/footer.php'); ?>
