<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Gamificame-login</title>

	<!--FAVICON -->
	<link href="img/LogoGamificame.png" rel="icon" type="image/x-icon" />

	<meta name="viewport" content="width=device-width, initial-scale=1, maximun-scale=1, user-scalable=no">

	<link rel="stylesheet" href="css/gamificame.css">
	<link rel="stylesheet" href="css/responsive-nav.css">

	<!--nice scrool-->
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.nicescroll.js"></script>

	<script src="ext/iphone-style-checkboxes.js" type="text/javascript"></script>
	<script src="js/responsive-nav.js"></script>

	<link rel="stylesheet" href="ext/iphone-style-checkboxes.css" type="text/css" media="screen" />
	<script>
		$(document).ready(
			function() {
			$("html").niceScroll();
			}
		);
	</script>
</head>
<body >
	<header>
	<img src='img/LogoGamificame3.png' width='160px'/>
		<nav class="nav-collapse">
			
			<ul>
				<li class="blanco">Inicio</li>
				<li class="blanco">Nosotros</li>
				<li class="blanco">Ingresar</li>
				<li class="blanco">Contacto</li>
			</ul>
		</nav>
	</header>
	<div class="navbarback">
		
	</div>