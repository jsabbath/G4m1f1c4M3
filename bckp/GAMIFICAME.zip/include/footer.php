	<footer>
		<!--p>
			<ul class="footer">
				<li class="verdeflat">Visitantes</li>
				<li class="azulceleste">Docente</li>
				<li class="rojoflat">Alumnos</li>
				<li class="celeste">Cursos</li>
				<li class="naranja">Premios</li>
			</ul>
		</p-->
	</footer>

	<script>
	 var navigation = responsiveNav(".nav-collapse", {
        init: function () {
          console.log("Responsive Nav Inited!");
        },
        open: function () {
          console.log("Opening…");
        },
        close: function () {
          console.log("Closing…");
        }
      });
	</script>
</body>
</html>