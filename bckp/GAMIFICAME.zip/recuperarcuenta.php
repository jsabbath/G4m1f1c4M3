<?php include('include/header.php'); ?>

	<div class="cuerpo">
		<h1>Recuperar mi cuenta</h1>
		<div>
			<p class="indicaciones">
				Si olvidaste tu cuenta, contraseña o no puedes acceder al portal de gamificame, lo unico que debes de hacer es rellenar los campos con la información que indicaye al momento de registrarte, antes de aceptar revisa y verifica bien tus datos.
				Que tengas un genial día.
			</p>
		</div>

		<!--login form-->
		<div class="form">
			<form action="perfil.php">
				<!--div class="input">
					<img class="imgavatar" src="img/askalex.jpg" alt="">
				</div-->
				<div class="input">
					<input type="text" maxlength="20" placeholder="Usuario"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="email" placeholder="Correo"  autocomplete="on" required>
				</div>
				<div class="input">
					<input type="password" placeholder="Contraseña que recuerdo"  autocomplete="on" required>
				</div>
				<div class="input">
					<input class="button naranja" type="reset" value="Limpiar">
				</div>
				<div class="input">
					<input class="button celeste" type="submit" value="Recuperar">
				</div>
				<div class="input">
					<a href="">Sácame de aquí</a>
				</div>
			</form>
			
		</div>
		<div class="fila">
			<ul>
				<a href="https://twitter.com" ><li></li></a>
				<a href="https://www.twitter.com"><li></li></a>
				<a href="https://www.googleplus.com"><li></li></a>
				<a href="https://www.linkedin.com"><li></li></a>
			</ul>
		</div>
		
	</div>
<?php include('include/footer.php'); ?>
